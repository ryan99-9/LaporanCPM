// let A = {
//     product: [{b:"g"},{c:"h",d:["x","y"]}],
//     Slider : [{aa:"aa", cc:"cc"},{bb:"bb"}],
//     users:[{id:2,username:"aaa"},{id:3,username:"ccc"}]
// }