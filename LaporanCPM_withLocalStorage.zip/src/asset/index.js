export const LOGO = require('./storeLogo.png')
export const MU = require('./mu.png')